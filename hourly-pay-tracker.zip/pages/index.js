import { useState } from "react";

const RATE = 49.28;
const OT_RATE = RATE * 1.5;
const DT_RATE = RATE * 2;

const daysOfWeek = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

export default function HourTracker() {
  const [hours, setHours] = useState(Array(7).fill(""));
  const [results, setResults] = useState(null);

  const handleChange = (index, value) => {
    const newHours = [...hours];
    newHours[index] = value;
    setHours(newHours);
  };

  const calculatePay = () => {
    let totalStraight = 0, totalOT = 0, totalDT = 0;

    hours.forEach((val, idx) => {
      const h = parseFloat(val);
      if (isNaN(h) || h <= 0) return;

      if (idx < 5) { // Mon–Fri
        totalStraight += Math.min(h, 8);
        totalOT += Math.max(0, h - 8);
      } else if (idx === 5) { // Saturday
        totalOT += h;
      } else if (idx === 6) { // Sunday
        totalDT += h;
      }
    });

    const straightPay = totalStraight * RATE;
    const otPay = totalOT * OT_RATE;
    const dtPay = totalDT * DT_RATE;
    const totalPay = straightPay + otPay + dtPay;

    setResults({ totalStraight, totalOT, totalDT, straightPay, otPay, dtPay, totalPay });
  };

  return (
    <div style={{ padding: '20px', maxWidth: '500px', margin: 'auto' }}>
      <h2>Weekly Hour Tracker</h2>
      {daysOfWeek.map((day, idx) => (
        <div key={day} style={{ marginBottom: '10px' }}>
          <label>{day}</label>
          <input
            type="number"
            placeholder="Hours worked"
            value={hours[idx]}
            onChange={(e) => handleChange(idx, e.target.value)}
            style={{ width: '100%', padding: '8px', marginTop: '4px' }}
          />
        </div>
      ))}
      <button onClick={calculatePay} style={{ padding: '10px', width: '100%', marginTop: '10px' }}>Calculate Pay</button>

      {results && (
        <div style={{ marginTop: '20px', border: '1px solid #ccc', padding: '10px' }}>
          <p>Straight Time Hours: {results.totalStraight.toFixed(2)}</p>
          <p>Overtime Hours: {results.totalOT.toFixed(2)}</p>
          <p>Double Time Hours: {results.totalDT.toFixed(2)}</p>
          <hr />
          <p>Straight Time Pay: ${results.straightPay.toFixed(2)}</p>
          <p>Overtime Pay: ${results.otPay.toFixed(2)}</p>
          <p>Double Time Pay: ${results.dtPay.toFixed(2)}</p>
          <h3>Total Pay: ${results.totalPay.toFixed(2)}</h3>
        </div>
      )}
    </div>
  );
}
